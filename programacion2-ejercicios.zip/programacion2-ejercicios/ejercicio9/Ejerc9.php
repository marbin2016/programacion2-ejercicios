<?php

$numeroIngresado=readline("Ingrese un numero por favor: ");
	
	function factorial($numero) {
		if ($numero==0) {
			$valor = 1;
		} else {
			$valor = $numero*factorial($numero-1);
		}
		return $valor;
	}
echo "El factorial del numero ingresado es: ".factorial($numeroIngresado);
?>
