<?php
$numero = readline("Ingrese el numero: ");

$nstring=(string)$numero;
 
$resultado="";
 
for($i=strlen($numero);$i>=0;$i--)
{
	$resultado.=$nstring[$i];
}

echo "El valor invertido es: ".(int)$resultado;	
?>
