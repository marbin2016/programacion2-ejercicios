<?php

class ValorPi
{
	
    function readline()
    {
		
        return rtrim(fgets(STDIN));
        
    }
    
}

$Dato = new ValorPi($nIngresado);
echo "Favor ingrese un número entero ","\n";
$nIngresado = "El número es: ";
echo $nIngresado;
$nIngresado = $Dato->readline();
$suma=0;
$contador=0;


for ($contador = 0; $contador <= $nIngresado; $contador++) {
	
    $resultado=4*(pow(-1,$contador)/(2*($contador)+1));
    $suma=$suma+$resultado;
}


echo "N: ".$nIngresado," Devuelve ", $suma,"\n";




?>
