<?php

$cadena=readline("Ingrese un string: ");
$vocales = 'aeiou';
$cantvocales = 0;
// comparar todas las letras de frase con las de vocales y contar coincidencias
for ($i=1;$i<=strlen($cadena);$i++) {
	for ($j=1;$j<=strlen($vocales);$j++) {
		if (substr($cadena,$i-1,$i-$i+1)==substr($vocales,$j-1,$j-$j+1)) {
				$cantvocales = $cantvocales+1;
			}
		}
	}
	echo 'La frase contiene ',$cantvocales,' vocales.';
?>
