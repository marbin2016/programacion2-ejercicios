<?php
$multiplicador=readline("Ingrese el numero multiplicador: ");
$multiplicando=readline("Ingrese el numero multiplicando: ");

$resultado=0; 

while($multiplicador>=1){
	if ($multiplicador%2 !=0){  
		$resultado=$resultado+$multiplicando;
		}
	$multiplicando *= 2;
	$multiplicador /= 2;
	}
echo "el resultado es: $resultado\n";

?>
