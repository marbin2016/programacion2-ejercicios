<?php
  
for ($dado1 = 1; $dado1 < 7; $dado1++) {  
    for ($dado2 = 1; $dado2 < 7; $dado2++) {  
        
        echo "$dado1--$dado2\n"; 
    }
}
?>

