<?php
$pi=(float)3.1416;
$radio = readline("Ingrese el radio del circulo: ");

$perimetro = 2 * $pi * $radio;
$area = $pi * ($radio * $radio);

echo "El perimetro del circulo es: ".$perimetro. "\n";
echo "El area del circulo es: ".$area;


?>
